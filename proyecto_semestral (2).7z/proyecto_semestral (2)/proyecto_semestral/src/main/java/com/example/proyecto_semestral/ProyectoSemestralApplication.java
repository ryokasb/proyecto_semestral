package com.example.proyecto_semestral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoSemestralApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoSemestralApplication.class, args);
	}

}
