package com.example.proyecto_semestral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoSemestralApplicationTests {

	@Test
	void contextLoads() {
	}

}
